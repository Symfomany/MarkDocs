Authentication with Github
==========================

This code is based on the kata: https://github.com/saro0h/playground/tree/kata-authentication

It presented how to unit test it with PHPUnit and Prohecy.
